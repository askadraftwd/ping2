const { Client, CommandInteraction, MessageEmbed, MessageActionRow, MessageButton, Options } = require("discord.js");




module.exports = {
    name: "avatar",
    description: "Fetch the avatar of a member in the guild",
    type: 'CHAT_INPUT',
    options: [
        {
            name: 'user',
            description: 'The member that will have their avatar grabbed',
            type: 'USER',
            required: true
        },
    ],
    /**
     *
     * @param {Client} client
     * @param {CommandInteraction} interaction
     * @param {String[]} args
     */
    run: async (client, interaction, args, options) => {
        const user = interaction.options.getUser("user")
        const avatarem = new MessageEmbed()
        .setColor("#2f3136")
        .setDescription(`avatar of ${user}`)
        .setImage(`${user.displayAvatarURL({dynamic: true})}`)
        .setFooter("sensei wise#0001")
        interaction.reply({embeds: [avatarem]}).catch(e => {
            interaction.reply({content: "an error occured", ephemeral: true})
        })
    }
};
