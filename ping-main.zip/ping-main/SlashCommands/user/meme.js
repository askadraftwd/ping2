const { Client,  MessageEmbed, Message, Interaction, CommandInteraction } = require('discord.js');
const axios = require("axios");
const client = require('../..');
const e = require('express');

module.exports = {
    name: 'meme',
    description: "grab random meme from r/memes",
    /**
     * @param {Client} client
     * @param {CommandInteraction} interaction
     * @param {String[]} args
     */
    run: async (client, interaction, args) => {
        let res = await axios.default.get(
            `https://www.reddit.com/r/memes/random/.json`
        );
        if(!res || !res.data || !res.data.length)
        interaction.reply({content: 'an error occured', ephemeral: true})
        res = res.data[0].data.children[0].data;
        const embed = new MessageEmbed()
        .setTitle(res.title)
        .setImage(res.url)
        .setURL(`https://www.reddit.com${res.permalink}`)
        .setFooter(`💬 ${res.num_comments} | sensei wise#001`);
        interaction.reply({
            embeds: [embed]
        }).catch(e => {
            interaction.reply({content: "an error occured", ephemeral: true})
        })
    
    }
}
