const { Client, CommandInteraction, MessageEmbed, MessageActionRow, MessageButton, Options } = require("discord.js");



module.exports = {
    name: "spam",
    description: "start the spam",
    type: 'CHAT_INPUT',
    /**
     *
     * @param {Client} client
     * @param {CommandInteraction} interaction
     * @param {String[]} args
     */
    run: async (client, interaction, args, options) => {
        const num = '999999999999999999999999999999999999'
        interaction.reply({content: 'your spam is starting ...', ephemeral: true})
        for (let step = 0; step < num; step++) {
       
         await interaction.channel.send("<@&1002763767832125551>")
         await new Promise(resolve => setTimeout(resolve, 1000));
   }
    
    }
};