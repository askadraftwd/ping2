# public-pingr

this is a ping bot coded in java script 

HEY EVERY ONE. THE SOURCE CODE IS HERE. In the secrets folder please replace everything respectfully, also look in the handlers folder and scroll down until you see a section with .get("your server id") <- replace with your server id as it says lol. you will also need node.js to install all the packages. When it says module not found in console please scroll up and look for the name eg. discord.js or glob. When you have fully setup the bot use the slash command /spam in the channel you want to be spammed in also replace the role id and stuff. thats all from me lmao

**LINKS YOU WILL NEED**
:link: https://discord.com/developers/applications
:link:https://mongodb.com
:link:https://nodejs.org

**Tutorial Video coming soon**
