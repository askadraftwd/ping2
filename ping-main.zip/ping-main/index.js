const { channel } = require("diagnostics_channel");
const { Client, Collection } = require("discord.js");
const express = require("express")
const app = express()
const fs = require("fs");
const { waitForDebugger } = require("inspector");
require("dotenv").config;
const client = new Client({
    intents: 32767,
});
const { token } = require("./secrets/config.json");


module.exports = client









client.commands = new Collection();
client.slashCommands = new Collection();
client.config = require("./secrets/config.json");
module.exports.Client = client

require("./Handler")(client);


client.login(token);

